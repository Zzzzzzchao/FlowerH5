1. add season filter


API key from openrouter

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